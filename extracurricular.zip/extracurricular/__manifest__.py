# -*- coding: utf-8 -*-
{
    'name': "Extracurricular",
    'depends': ['hr'],
    'data': [
            'security/ir.model.access.csv',
            'views/extracurricular.xml',
            ],
    'installable': True,
}
